Championship Manager 1989/90 update for CM 01/02: Beta 5, April 8th 2017
https://cm8990.wordpress.com
Simon Treanor
======================================================================================

Introduction
======================================================================================
This is a project that aims to back date Championship Manager 01/02 to the 1989/90 season. It is a beta, and very much a work in progress, so a large number of teams will still have their squads from the early 2000s. However, a large number of teams have been completed, so the English, Scottish, German and Italian leagues are perfectly playable, albeit with a few anachronistic players.

See https://cm8990.wordpress.com/frequently-asked-questions/ for FAQs.

Requirements and Installation
======================================================================================
See https://cm8990.wordpress.com/installation-instructions/ for more info.

Feedback
======================================================================================
I'm always keen to hear feedback, as data from the era is hard to find. I'm particularly interested in specific player positions, player attributes, missing players and backroom staff, but any feedback is welcome. You can contact me in one of three ways:

1. The form at https://cm8990.wordpress.com/contact/
2. This thread: http://champman0102.co.uk/showthread.php?t=8766
3. Email me at simon.treanor@btinternet.com

Disclaimer
======================================================================================

I do not accept any responsibilty for any damage to your installation or your PC, as an alleged result
of the download and/or installation of this update.