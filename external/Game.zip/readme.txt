IMPORTANT NOTICE

ALL STATISTICAL INFORMATION, QUOTES AND OTHER COMMENTARY IN CHAMPIONSHIP
MANAGER IS FICTITIOUS. NONE OF THESE DETAILS (INCLUDING MATCH RESULTS,
PLAYERS' CONTRACT AND SALARY DETAILS) HAVE BEEN AUTHORISED OR ENDORSED BY
THE PEOPLE REFERRED TO IN CHAMPIONSHIP MANAGER. ALL SUCH INFORMATION HAS
BEEN CREATED SOLELY FOR THE GAME.

======================================================================
                                Release Notes
======================================================================

Championship Manager 01/02
Developed by: Sports Interactive Ltd
Published by: Eidos Interactive Ltd

--------------------------------------
For the latest information and updates
--------------------------------------

Visit the following home pages on the web:

Sports Interactive Ltd - http://www.sigames.com 
Eidos Interactive Ltd  - http://www.eidos.com

-----------------------------------
Technical Support 
-----------------------------------

Address		Unit 2 
                Holford Way 
                Birmingham 
                B6 7AX.

Phone	        0121 356 0831
Web	        http://www.eidos.com/support.html


======================================================================
                          Troubleshooting
======================================================================
----------------
Copy Protection
----------------

Should you experience a problem when trying to run Championship Manager where the game asks for the CD
even though it's already in your drive please try the following :

* Under 'My Computer' right click and select properties
* Click on the Device manager tab
* Right click and select the properties of the CD Rom drive in question
* Search for the option 'DMA'

If this is enabled, disable it, if its disabled enable it. This has been known to solve the issue on drives where it hasn't recognised the CD

Customer services have been aware of this problem which affects a small minority of users

----------------
Maximum Database
----------------

Within the game options screen you can select to run the game with a MAXIMUM database. 
This will ensure all player information is loaded however we strongly advise that only users 
with high spec machines attempt this process due to the extra load on this places 
on your computer.

--------------
Install issues
--------------

It has been noticed that InstallShield can report that there is enough hard disk
space free to install Championship Manager 01/02, yet run out of disk space during install.

This happens when installing Championship Manager 01/02 to a different drive to the one
windows is installed upon. The disk space reported is on the target drive, yet
Installshield unpacks data to the windows drive in a temporary directory.

If you get this problem you need to clear space on your windows drive to allow
InstallShield the room to unpack data.

------------
Video issues
------------

Some video drivers do not properly support DirectDraw full-screen
in 16-bit colour at any resolution. If you are unable to
start Championship Manager 01/02 which defaults to full-screen mode,
start Championship Manager 01/02 with the command line option -windowed

In order for Championship Manager 01/02 to work in full-screen mode you must
have DirectX installed, and your graphics adapter must support 800x600
16-bit colour mode.

If Championship Manager 01/02 fails to open in windowed mode, ensure that your
Windows desktop is in 16-Bit colour mode with at least 800x600 pixel resolution.

------------
Sound issues
------------

Championship Manager 01/02 uses DirectX to play in-match sounds. If your
sound does not work and it is turned on in the 'Game Settings' dialogue,
make sure that DirectX is installed correctly and configured to use your
sound card.

-------------------
Network play issues
-------------------

The network play option uses TCP/IP. If you are unable to create/join
a network game check that you have TCP/IP protocol installed. 

To do this:

* Open the control panel. (Start->Settings->Control Panel)
* Click on the network icon.

If TCP/IP is not listed in the window you must add it:

* Click on Add.
* Select Protocol
* Select Microsoft
* Select TCP/IP
* Click on Ok

NOTE: You can only play in a game that is on the same subnet mask,
To check this:

* Open the control panel. (Start->Settings->Control Panel)
* Click on the network icon.
* Click on TCP/IP in the list - If you have more than one network binding
  there will be more than one entry, select the one that is connected to
  your LAN adapter.
* Click on Properties

Your subnet mask is displayed on the IP Address tab. If this is blank or
differs from the computer you are trying to connect to, see your network
administrator.

If you do not have a network administrator, enter 255.255.255.0 in the sub net field.

Due to the configuration of some networks, the name of the network game may not appear
on the Join Network Game screen. In this case, it is still possible to join the game by 
typing the server's IP address into the edit box. The server's IP address can be found on 
the Manager Status screen on the server.

--------------------
Command Line Options
--------------------

The command line options are:

cm0102.exe [-windowed|-nosound|-nonetwork|-verifypics|-verifyhist|-verifysounds]

A brief description of each:

-windowed     Starts Championship Manager 01/02 in a window instead of full-screen. This option
              should be used if the game is unable to open in full-screen mode.

-nosound      Stops the sound layer from starting. This option should be used if DirectX
              is unable to communicate with your sound card without error.

-nonetwork    Stops the network layer from starting. This option should be used if you get
              errors as the game tries to open the network (i.e. Unable to open socket) 
            
-verifypics   Checks the background picture configuration file for errors as a new game
              starts. This option is only needed if you have modified the pics.cfg file.

-verifyhist   Checks the history files for validity as a new game starts. This option is
              only needed if you have added new history files.

-verifysounds Checks the in match sound files are valid as the first match starts. This
              option is only needed if you have changed/updated the match events config file. 

-dontcheckram Disables checking of available RAM when selecting leagues to run; please note that
              turning this option off may cause the game to malfunction if too many leagues are
              selected.

-------------------
Printing the Screen
-------------------

There is no option to print the screen in Championship Manager 01/02. If you want to print a
copy of the screen (or save to file), then run the game in full-screen mode, hit the print
screen key and select paste in your art package. You can now save or print the screen image.

-----------------------
Option is not available
-----------------------

Some game options such as "Save Game", "Restart Game" and "Exit Game" are not always
available. This is because at least one player in the game (including Network and
Multi-players) has a screen open that must be responded to. If any of these options are
unavailable, check the screens you (and any other player in the game) has open.

------------
Requirements
------------

The Minimum requirements for running CM01/02 are:

133 Pentium PC (233 recommended)
16 MB Ram (64MB recommended for over 4 multiple leagues)
1MB Video RAM (2MB recommended)
Ethernet Adapter (Network Play Only)

-------------
Speed Issues 
-------------

If you find the game is slow to run then you can try the following to speed things up:

1 - Use Minimum Database
Select Minimum Database from the Game Settings menu before starting the game, this will
load a cut-down database with fewer players and clubs present which will speed up the 
game.

2 - Select Fewer leagues
If you have a slow PC, try selecting fewer leagues as this will cut down on the in
game processing (see requirements above for memory recommendations).

3 - Slow screen changes
This may be because of an old style video card (for all you geeks out there 16bit colour
is held in video memory as RGB 555 or 565 depending upon your video card) .. CM01/02 will
be slower when changing screens with a RGB 555 video card. To test this simply turn
off picture changes in the Game Settings menu within CM01/02.

4 - Close all other applications 
Ensure that CM01/02 is the only application that you are running, any other applications 
will use up valuable system memory which may slow down the game.

5 - Clear Disk Space
Ensure that your main hard-disk has a lot of spare disk space for windows to use when
needed.

--------
Upgrades
--------

If the previous tips didn't speed things up enough for your liking and you are considering
upgrading your system then bear the following in mind:

1 - Frequent Hard Disk Access
This indicates that your system is low on memory and is using virtual memory (stored on
the Hard disk), the best way to speed up your game will be to purchase more memory.

2 - Slow Processing with no hard disk access
You best bet in this case would be to upgrade the Processor.

-------------
Memory Issues
-------------

If CM01/02 displays a message stating that there is not enough system memory to continue, then
the game has used up all available physical and virtual memory. To increase the amount of
memory available to CM01/02 try closing down any other applications you are currenly running,
or increase the amount of disk space available for virtual memory.

For furthur information on configuring your system's virtual memory, consult your Windows
operating system manual.

------------------
Reliability Issues
------------------

During the course of playing CM01/02, the program reads and writes a large amount of information
to your hard disk - more so than most other games. If your hard disk contains any surface 
errors this may cause the game to crash or behave unreliably. 

It is advisable to check your hard disk for surface errors periodically using Microsoft 
ScanDisk (a utility program that is part of your Windows installation).

